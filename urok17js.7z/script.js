var name;
name = 'Василий';
alert(name);
 var admin = name;
 alert(admin);
 var num1 = 10;
 var num2 = 15;
 ans = num1 + num2;
 alert(admin);
 alert(ans);

 
 